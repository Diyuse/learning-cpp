#pragma once
#include "Shape.h"

class Circle : public Shape {
public:
    Circle();
    Circle(double width);
    virtual ~Circle();
    double Area();
};