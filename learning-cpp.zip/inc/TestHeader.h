#pragma once //preprocessor directive, allows us to not have the ifndef block and just include.mark

void WaitForInput();
